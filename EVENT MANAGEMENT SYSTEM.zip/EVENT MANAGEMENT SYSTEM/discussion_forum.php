<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch event discussions
$event_id = isset($_GET['event_id']) ? intval($_GET['event_id']) : 0;

// Check if the event_id exists in the events table
$check_event_sql = "SELECT * FROM events WHERE event_id = '$event_id'";
$event_result = $conn->query($check_event_sql);

if ($event_result->num_rows == 0) {
    die("Invalid event ID. The event does not exist.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Add a new discussion
    $user_id = $_SESSION['user_id'];
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Insert the discussion
    $insert_sql = "INSERT INTO discussions (event_id, user_id, message) VALUES ('$event_id', '$user_id', '$message')";
    if ($conn->query($insert_sql) === TRUE) {
        echo "New discussion posted successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}

$discussions_sql = "SELECT discussions.*, users.username FROM discussions 
                    INNER JOIN users ON discussions.user_id = users.user_id 
                    WHERE discussions.event_id = '$event_id'
                    ORDER BY discussions.created_at DESC";
$discussions_result = $conn->query($discussions_sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discussion Forum</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="index.php#features">Features</a></li>
            <li><a href="event_discovery.php">Events</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    </nav>

    <h2>Discussion Forum</h2>

    <div class="discussion-form">
        <form method="POST" action="discussion_forum.php?event_id=<?= $event_id ?>">
            <textarea name="message" placeholder="Post a message..." required></textarea>
            <input type="submit" value="Post">
        </form>
    </div>

    <div class="discussions">
        <?php if ($discussions_result && $discussions_result->num_rows > 0): ?>
            <?php while ($discussion = $discussions_result->fetch_assoc()): ?>
                <div class="discussion">
                    <p><strong><?= htmlspecialchars($discussion['username']); ?></strong> (<?= htmlspecialchars($discussion['created_at']); ?>)</p>
                    <p><?= htmlspecialchars($discussion['message']); ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No discussions yet. Be the first to post!</p>
        <?php endif; ?>
    </div>
</body>

</html>