<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize filters
$location = isset($_GET['location']) ? mysqli_real_escape_string($conn, $_GET['location']) : '';
$date = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';
$category = isset($_GET['category']) ? mysqli_real_escape_string($conn, $_GET['category']) : '';
$keyword = isset($_GET['keyword']) ? mysqli_real_escape_string($conn, $_GET['keyword']) : '';
$sort = isset($_GET['sort']) ? mysqli_real_escape_string($conn, $_GET['sort']) : 'date';

// Build query with filters
$query = "SELECT * FROM events WHERE privacy = 'public'";
if ($location) {
    $query .= " AND location LIKE '%$location%'";
}
if ($date) {
    $query .= " AND date >= '$date'";
}
if ($category) {
    $query .= " AND description LIKE '%$category%'";
}
if ($keyword) {
    $query .= " AND (title LIKE '%$keyword%' OR description LIKE '%$keyword%')";
}
$query .= " ORDER BY $sort ASC";

$result = $conn->query($query);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover Events</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>

            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    </nav>

    <h2 style="color: white;">Filter Nearby Events</h2>

    <!-- Filters Section -->
    <form method="GET" action="event_discovery.php" class="filter-form">
        <div>
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" placeholder="Enter location" value="<?= htmlspecialchars($location); ?>">
        </div>
        <div>
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" value="<?= htmlspecialchars($date); ?>">
        </div>
        <div>
            <label for="category">Category:</label>
            <input type="text" id="category" name="category" placeholder="Enter category" value="<?= htmlspecialchars($category); ?>">
        </div>
        <div>
            <label for="keyword">Keyword:</label>
            <input type="text" id="keyword" name="keyword" placeholder="Enter keyword" value="<?= htmlspecialchars($keyword); ?>">
        </div>
        <div>
            <label for="sort">Sort By:</label>
            <select id="sort" name="sort">
                <option value="date" <?= $sort === 'date' ? 'selected' : ''; ?>>Date</option>
                <option value="title" <?= $sort === 'title' ? 'selected' : ''; ?>>Title</option>
                <option value="location" <?= $sort === 'location' ? 'selected' : ''; ?>>Location</option>
            </select>
        </div>
        <input type="submit" value="Search">
    </form>

    <!-- Events List -->
    <div class="events-list">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($event = $result->fetch_assoc()): ?>
                <div class="event-card">
                    <h3><?= htmlspecialchars($event['title']); ?></h3>
                    <p><strong>Date:</strong> <?= htmlspecialchars($event['date']); ?></p>
                    <p><strong>Time:</strong> <?= htmlspecialchars($event['time']); ?></p>
                    <p><strong>Location:</strong> <?= htmlspecialchars($event['location']); ?></p>
                    <p><?= htmlspecialchars($event['description']); ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No events found. Try adjusting your filters.</p>
        <?php endif; ?>
    </div>
</body>

</html>