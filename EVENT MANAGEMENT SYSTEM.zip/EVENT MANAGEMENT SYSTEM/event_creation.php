<?php
// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Please log in to create an event.');
            window.location.href = 'login.php';
          </script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $organizer_id = $_SESSION['user_id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $time = mysqli_real_escape_string($conn, $_POST['time']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $ticket_price = mysqli_real_escape_string($conn, $_POST['ticket_price']);
    $privacy = mysqli_real_escape_string($conn, $_POST['privacy']);

    // Validate input
    if (!empty($title) && !empty($description) && !empty($date) && !empty($time) && !empty($location) && !empty($ticket_price) && !empty($privacy)) {
        // Insert the event into the events table
        $sql = "INSERT INTO events (organizer_id, title, description, date, time, location, ticket_price, privacy) 
                VALUES ('$organizer_id', '$title', '$description', '$date', '$time', '$location', '$ticket_price', '$privacy')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>
                    alert('Event created successfully!');
                    window.location.href = 'dashboard.php';
                  </script>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Please fill in all fields.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Event</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="contact_form.html">Contact Us</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
        <div class="hamburger" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <h2 style="color: white;">Create Event</h2>
    <form action="event_creation.php" method="POST">
        <label for="title">Event Title:</label>
        <input type="text" id="title" name="title" required><br>

        <label for="description">Event Description:</label>
        <textarea id="description" name="description" rows="4" required></textarea><br>

        <label for="date">Event Date:</label>
        <input type="date" id="date" name="date" required><br>

        <label for="time">Event Time:</label>
        <input type="time" id="time" name="time" required><br>

        <label for="location">Event Location:</label>
        <input type="text" id="location" name="location" required><br>

        <label for="ticket_price">Ticket Price:</label>
        <input type="number" id="ticket_price" name="ticket_price" step="0.01" required><br>

        <label for="privacy">Privacy:</label>
        <select id="privacy" name="privacy" required>
            <option value="public">Public</option>
            <option value="private">Private</option>
        </select><br>

        <input type="submit" value="Create Event">
    </form>
</body>
</html>
