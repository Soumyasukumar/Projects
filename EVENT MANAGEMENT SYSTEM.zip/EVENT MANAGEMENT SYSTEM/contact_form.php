<?php
// Database connection
$servername = "localhost";
$username = "root"; // your database username
$password = ""; // your database password
$dbname = "EventManagementSystem";

$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Validate input
    if (!empty($name) && !empty($email) && !empty($message)) {
        // Insert the data into the contact_messages table
        $sql = "INSERT INTO contact_messages (name, email, message) 
                VALUES ('$name', '$email', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "<script>
            alert('Thank you for contacting us. We will get back to you shortly.');
            setTimeout(function() {
                window.location.href = 'index.php'; // Redirect after 2 seconds (or you can stay on the same page)
            }, 100); // 
        </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
    } else {
        echo "Please fill in all fields.";
    }
}

// Close the database connection
$conn->close();
?>
