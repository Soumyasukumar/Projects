<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Please log in to purchase tickets.');
            window.location.href = 'login.php';
          </script>";
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch available events
$events_sql = "SELECT * FROM events WHERE privacy = 'public'";
$events_result = $conn->query($events_sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $event_id = mysqli_real_escape_string($conn, $_POST['event_id']);
    $ticket_type = mysqli_real_escape_string($conn, $_POST['ticket_type']);
    $user_id = $_SESSION['user_id'];

    // Insert ticket purchase into tickets table
    $insert_ticket_sql = "INSERT INTO tickets (event_id, user_id, ticket_type) 
                          VALUES ('$event_id', '$user_id', '$ticket_type')";

    if ($conn->query($insert_ticket_sql) === TRUE) {
        echo "<script>
                alert('Ticket purchased successfully!');
                window.location.href = 'dashboard.php';
              </script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Ticket</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>

            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    </nav>

    <h2 style="color: white;">Purchase Ticket</h2>
    <form action="ticket_purchase.php" method="POST" class="form-container">
        <label for="event_id">Select Event:</label>
        <select id="event_id" name="event_id" required>
            <?php while ($event = $events_result->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($event['event_id']); ?>">
                    <?= htmlspecialchars($event['title'] . ' (' . $event['date'] . ')'); ?>
                </option>
            <?php endwhile; ?>
        </select><br>

        <label for="ticket_type">Ticket Type:</label>
        <select id="ticket_type" name="ticket_type" required>
            <option value="Regular">Regular</option>
            <option value="VIP">VIP</option>
        </select><br>

        <input type="submit" value="Purchase Ticket">
    </form>
</body>

</html>