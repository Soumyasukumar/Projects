<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Please log in to view your tickets.');
            window.location.href = 'login.php';
          </script>";
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Fetch tickets purchased by the user
$tickets_sql = "SELECT tickets.ticket_id, tickets.ticket_type, events.event_id, events.title, events.date, events.time, events.location
                FROM tickets
                INNER JOIN events ON tickets.event_id = events.event_id
                WHERE tickets.user_id = '$user_id'";
$tickets_result = $conn->query($tickets_sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tickets</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="event_discovery.php">Events</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    </nav>

    <h2 style="color: white;">My Tickets</h2>
    <?php if ($tickets_result->num_rows > 0): ?>
        <table class="dashboard-table">
            <thead>
                <tr>
                    <th>Ticket ID</th>
                    <th>Event Title</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Location</th>
                    <th>Ticket Type</th>
                    <th>Action</th> <!-- New column for the buttons -->
                </tr>
            </thead>
            <tbody>
                <?php while ($ticket = $tickets_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($ticket['ticket_id']); ?></td>
                        <td><?= htmlspecialchars($ticket['title']); ?></td>
                        <td><?= htmlspecialchars($ticket['date']); ?></td>
                        <td><?= htmlspecialchars($ticket['time']); ?></td>
                        <td><?= htmlspecialchars($ticket['location']); ?></td>
                        <td><?= htmlspecialchars($ticket['ticket_type']); ?></td>
                        <td>
                            <!-- "Go and Vote" button linking to polls for the corresponding event -->
                            <a href="polls.php?event_id=<?= $ticket['event_id']; ?>" class="btn">Go and Vote</a>
                            <!-- "Discussion" button linking to the discussion forum for the corresponding event -->
                            <a href="discussion_forum.php?event_id=<?= $ticket['event_id']; ?>" class="btn">Discussion</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have not purchased any tickets yet.</p>
    <?php endif; ?>
</body>

</html>