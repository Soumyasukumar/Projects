<?php
// Start the session to check login status
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management System</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>
            <li><a href="event_discovery.php">Events</a></li>
            <li><a href="contact_form.html">Contact Us</a></li>
            <li>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true): ?>
                    <a href="logout.php" class="btn">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn">Login/Signup</a>
                <?php endif; ?>
            </li>
        </ul>
        <div class="hamburger" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <!-- Header Section -->
    <header id="home">
        <div class="header-container">
            <h1 class="header-title">Welcome to Event Management System</h1>
            <p class="header-description">Streamline your events and engage your audience effortlessly.</p>
            <a href="#features" class="header-button">Explore Features</a>
        </div>
    </header>

    <!-- Features Section -->
    <section id="features">
        <h2>Features</h2>
        <div class="features-container">
            <a href="signup.php">
                <div class="feature">
                    <i class="icon">👤</i>
                    <h3>User Registration</h3>
                    <p>Create an account and securely log in to manage or attend events.</p>
                </div>
            </a>
            <div class="feature">
                <a href="event_creation.php" class="feature-link">
                    <i class="icon">📅</i>
                    <h3>Event Creation</h3>
                    <p>Plan and customize events with ease.</p>
                </a>
            </div>
            <div class="feature">
                <a href="ticket_purchase.php">
                    <i class="icon">🎟️</i>
                    <h3>Ticketing</h3>
                    <p>Buy, sell, and manage event tickets effortlessly.</p>
                </a>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>© 2024 Event Management System. All rights reserved.</p>
    </footer>

    <script src="assets/js/scripts.js"></script>
</body>

</html>
