<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Please log in to vote.');
            window.location.href = 'login.php';
          </script>";
    exit();
}

// Check if 'event_id' is passed in the query string
if (!isset($_GET['event_id']) || empty($_GET['event_id'])) {
    echo "<script>
            alert('Event ID is missing.');
            window.location.href = 'event_discovery.php'; // Redirect to the events discovery page or any other page
          </script>";
    exit();
}

$event_id = $_GET['event_id']; // Get the event ID from the query string

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the poll questions for this event
$poll_sql = "SELECT * FROM polls WHERE event_id = '$event_id'";
$poll_result = $conn->query($poll_sql);

// Check if the form is submitted to record a vote
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if option_id is set
    if (isset($_POST['option_id']) && !empty($_POST['option_id'])) {
        $poll_id = $_POST['poll_id'];
        $option_id = $_POST['option_id'];

        // Insert vote into the database
        $vote_sql = "INSERT INTO poll_votes (poll_id, user_id, option_id) VALUES ('$poll_id', '" . $_SESSION['user_id'] . "', '$option_id')";
        if ($conn->query($vote_sql) === TRUE) {
            // Increment the vote count for the chosen option
            $increment_vote_sql = "UPDATE poll_options SET vote_count = vote_count + 1 WHERE option_id = '$option_id'";
            $conn->query($increment_vote_sql);

            echo "<script>alert('Your vote has been submitted!'); window.location.href = 'dashboard.php';</script>";
        } else {
            echo "<script>alert('Error voting. Please try again.'); window.location.href = 'dashboard.php';</script>";
        }
    } else {
        // Handle the case where no option was selected
        echo "<script>alert('Please select an option to vote.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote on Poll</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="index.php#features">Features</a></li>
            <li><a href="event_discovery.php">Events</a></li>
            <li><a href="contact_form.html">Contact Us</a></li>
            <li><a href="login.php" class="btn">Login/Signup</a></li>
        </ul>
        <div class="hamburger" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <h2 style="color: white;">Vote on Poll</h2>

    <?php if ($poll_result->num_rows > 0): ?>
        <?php while ($poll = $poll_result->fetch_assoc()): ?>
            <h3 style="margin-left: 30%; font-size: 30px; color:yellow; font-weight:bolder"><?= htmlspecialchars($poll['question']); ?></h3>

            <form action="polls.php?event_id=<?= $event_id; ?>" method="POST">
                <input type="hidden" name="poll_id" value="<?= $poll['poll_id']; ?>">

                <?php
                // Fetch poll options
                $options_sql = "SELECT * FROM poll_options WHERE poll_id = '" . $poll['poll_id'] . "'";
                $options_result = $conn->query($options_sql);
                ?>

                <?php while ($option = $options_result->fetch_assoc()): ?>
                    <input type="radio" name="option_id" value="<?= $option['option_id']; ?>" required>
                    <label><?= htmlspecialchars($option['option_text']); ?></label><br>
                <?php endwhile; ?>

                <input type="submit" value="Submit Vote">
            </form>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No polls available for this event.</p>
    <?php endif; ?>

    <footer>
        <p>&copy; 2024 Event Management. All rights reserved.</p>
    </footer>

    <script src="script.js"></script>
</body>

</html>