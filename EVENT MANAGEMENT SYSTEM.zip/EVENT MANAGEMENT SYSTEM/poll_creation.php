<?php
// Establish database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted and the event_id is set
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if event_id is set in the POST data
    if (isset($_POST['event_id'])) {
        $event_id = $_POST['event_id'];

        // Sanitize the event_id to prevent SQL injection
        $event_id = $conn->real_escape_string($event_id);

        // Check if the event_id exists in the events table
        $check_event_sql = "SELECT * FROM events WHERE event_id = '$event_id'";
        $check_event_result = $conn->query($check_event_sql);

        if ($check_event_result->num_rows == 0) {
            echo "<script>alert('Invalid Event ID. Please check the Event ID and try again.');</script>";
        } else {
            // Proceed with poll creation
            $question = isset($_POST['question']) ? $_POST['question'] : '';
            $options = isset($_POST['options']) ? $_POST['options'] : '';

            // Validate other inputs
            if (empty($question) || empty($options)) {
                echo "<script>alert('All fields are required.');</script>";
            } else {
                // Insert the poll into the polls table
                $poll_sql = "INSERT INTO polls (event_id, question) VALUES ('$event_id', '$question')";
                if ($conn->query($poll_sql) === TRUE) {
                    $poll_id = $conn->insert_id; // Get the ID of the newly inserted poll

                    // Insert poll options into the database
                    $options_array = explode(',', $options);
                    foreach ($options_array as $option) {
                        $option = trim($option); // Trim extra spaces
                        $option_sql = "INSERT INTO poll_options (poll_id, option_text) VALUES ('$poll_id', '$option')";
                        $conn->query($option_sql);
                    }

                    echo "<script>alert('Poll created successfully!'); window.location.href = 'dashboard.php';</script>";
                } else {
                    echo "<script>alert('Error creating poll. Please try again.');</script>";
                }
            }
        }
    } else {
        echo "<script>alert('Event ID is required.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Poll</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to global CSS -->
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>
            <li><a href="event_discovery.php">Events</a></li>
            <li><a href="contact_form.html">Contact Us</a></li>
            <li><a href="login.php" class="btn">Login/Signup</a></li>
        </ul>
        <div class="hamburger" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <!-- Poll Creation Form -->
    <div class="container">
        <h2>Create Poll</h2>
        <form action="poll_creation.php" method="POST">
            <label for="event_id">Event ID:</label>
            <input type="text" name="event_id" required><br>

            <label for="question">Poll Question:</label>
            <input type="text" name="question" required><br>

            <label for="options">Poll Options (comma separated):</label>
            <input type="text" name="options" required><br>

            <input type="submit" value="Create Poll">
        </form>
    </div>

</body>

</html>