<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Please log in to view attendees.');
            window.location.href = 'login.php';
          </script>";
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$organizer_id = $_SESSION['user_id'];

// Fetch attendees for events created by the organizer
$attendees_sql = "SELECT tickets.event_id, tickets.ticket_type, users.username, users.email
                  FROM tickets 
                  INNER JOIN users ON tickets.user_id = users.user_id
                  WHERE tickets.event_id IN (SELECT event_id FROM events WHERE organizer_id = '$organizer_id')";
$attendees_result = $conn->query($attendees_sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendee List</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>

            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    </nav>

    <h2>Attendee List</h2>
    <?php if ($attendees_result->num_rows > 0): ?>
        <table class="dashboard-table">
            <thead>
                <tr>
                    <th>Event ID</th>
                    <th>Attendee Name</th>
                    <th>Email</th>
                    <th>Ticket Type</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($attendee = $attendees_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($attendee['event_id']); ?></td>
                        <td><?= htmlspecialchars($attendee['username']); ?></td>
                        <td><?= htmlspecialchars($attendee['email']); ?></td>
                        <td><?= htmlspecialchars($attendee['ticket_type']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No attendees yet.</p>
    <?php endif; ?>
</body>

</html>