<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Please log in to access the dashboard.');
            window.location.href = 'login.php';
          </script>";
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "root", "eventmanagementsystem");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$organizer_id = $_SESSION['user_id'];

// Fetch events created by the logged-in user
$sql = "SELECT * FROM events WHERE organizer_id = '$organizer_id'";
$events_result = $conn->query($sql);

// Fetch attendees for events created by the organizer
$attendees_sql = "SELECT tickets.event_id, users.username, users.email
                  FROM tickets 
                  INNER JOIN users ON tickets.user_id = users.user_id
                  WHERE tickets.event_id IN (SELECT event_id FROM events WHERE organizer_id = '$organizer_id')";
$attendees_result = $conn->query($attendees_sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><a href="#">Event Management</a></div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#features">Features</a></li>

            <li><a href="event_creation.php">Create Event</a></li>
            <li><a href="contact_form.html">Contact Us</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
        <div class="hamburger" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <h2 style="color: white;">Your Dashboard</h2>

    <section class="dashboard-section">
        <h3>Manage Events</h3>
        <?php if ($events_result->num_rows > 0): ?>
            <table class="dashboard-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($event = $events_result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($event['title']); ?></td>
                            <td><?= htmlspecialchars($event['date']); ?></td>
                            <td><?= htmlspecialchars($event['time']); ?></td>
                            <td><?= htmlspecialchars($event['location']); ?></td>
                            <td>
                                <!-- Button to create poll -->
                                <a href="poll_creation.php?event_id=<?= $event['event_id']; ?>" class="btn">Create Poll</a>
                                <!-- Button to manage existing polls -->
                                <a href="polls.php?event_id=<?= $event['event_id']; ?>" class="btn">Manage Polls</a>
                                <!-- New "Go and Vote" button for attendees -->
                                <a href="polls.php?event_id=<?= $event['event_id']; ?>" class="btn">Go and Vote</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>You have not created any events yet.</p>
        <?php endif; ?>
    </section>

    <section class="dashboard-section">
        <h3>Attendees</h3>
        <?php if ($attendees_result->num_rows > 0): ?>
            <table class="dashboard-table">
                <thead>
                    <tr>
                        <th>Event ID</th>
                        <th>Attendee Name</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($attendee = $attendees_result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($attendee['event_id']); ?></td>
                            <td><?= htmlspecialchars($attendee['username']); ?></td>
                            <td><?= htmlspecialchars($attendee['email']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No attendees yet.</p>
        <?php endif; ?>
    </section>

    <section class="dashboard-section">
        <h3>My Ticket Dashboard</h3>
        <div class="dashboard-boxes">
            <!-- Existing sections for events and attendees -->

            <!-- New box for purchased tickets -->
            <div class="dashboard-box" onclick="window.location.href='my_tickets.php'">
                <h4>My Tickets</h4>
                <p>View all the tickets you’ve purchased.</p>
            </div>
        </div>
    </section>

</body>

</html>