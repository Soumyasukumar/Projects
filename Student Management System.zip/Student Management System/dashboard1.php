<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

.header {
  background-color: #90EE90;
  color: #000080;
  padding: 10px;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
}

.header img {
  width: 20px;
  margin-right: 10px;
}

.container {
  background-color: #F0FFF0;
  padding: 20px;
}

.nav {
  display: flex;
  flex-direction: column;
  width: 200px;
  border-right: 1px solid #ccc;
}

.nav a {
  display: block;
  padding: 10px;
  color: #000080;
  text-decoration: none;
}

.nav a:hover {
  background-color: #D0F0C0;
}

.content {
  margin-left: 210px;
  padding: 20px;
}

.content h1 {
  text-align: center;
  color: #FF0000;
}
</style>
</head>
<body>

<div class="header">
  <!-- <img src="https://www.iconfinder.com/icons/2199553/student_people_man_avatar_icon" alt="Student Icon"> -->
  <h1>Student Management System</h1>
</div>

<div class="container">
  <div class="nav">
    <a href="dashboard1.php">Dashboard</a>
    <a href="student.php">Add New Student</a>
    <a href="manage.php">Manage All Student</a>
    <a href="promote.php">Promote Student</a>
    <a href="#">Change Password</a>
    <a href="./Admin.php">Logout</a>
  </div>

  <div class="content">
    <h1>Welcome to Student Management System Dashboard</h1>
  </div>
</div>

</body>
</html>