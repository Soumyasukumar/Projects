<?php
include 'dbconnect.php';
$id = $_GET['id'];
$qry = "SELECT * FROM `student` WHERE `id`=$id  ";
$run = mysqli_query($link, $qry);
$data = $run -> fetch_assoc();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration Form</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 10px 0 5px;
            font-weight: bold;
        }

        label span {
            color: red;
        }

        input[type="text"],
        input[type="date"],
        input[type="email"],
        input[type="file"],
        select {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            padding: 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>STUDENT REGISTRATION FORM</h1>
        <form action="" method="post">
            <label for="name">Name of Student<span>*</span></label>
            <input type="text" id="name" name="name" required>

            <label for="register">Registration No<span>*</span></label>
            <input type="text" id="register" name="register" required>

            <label for="date">Date of Admission<span>*</span></label>
            <input type="date" id="date" name="date" required>

            <label for="class">Class<span>*</span></label>
            <select id="class" name="class" required>
                <option value="">Select Class</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>

                <!-- Add options here -->
            </select>

            <label for="aadhar">Aadhaar Card No</label>
            <input type="text" id="aadhar" name="aadhar">

            <label for="father">Fathers Name<span>*</span></label>
            <input type="text" id="father" name="father" required>

            <label for="mother">Mother Name<span>*</span></label>
            <input type="text" id="mother" name="mother" required>

            <label for="mobile">Mobile No<span>*</span></label>
            <input type="text" id="mobile" name="mobile" required>

            <label for="email">Email Id</label>
            <input type="email" id="email" name="email">

            <!-- <label for="upload_photo">Upload Photo</label>
            <input type="file" id="upload_photo" name="upload_photo"> -->

            <button type="submit" name="submit" class="btn btn-primary">submit</button>
        </form>
    </div>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $register = $_POST['register'];
    $date = $_POST['date'];
    $class = $_POST['class'];
    $aadhar = $_POST['aadhar'];
    $father = $_POST['father'];
    $mother = $_POST['mother'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];

    $qry = "UPDATE `student` SET `name`='$name',`register`='$register',`date`='$date',
    `class`='$class',`aadhar`='$aadhar',`father`='$father',`mother`='$mother',`mobile`='$mobile',
    `email`='$email' WHERE `id` = '$id' " ;
    $run = mysqli_query($link, $qry);
    if ($run) {
?>
        <script>
            alert("Data updated successfully")
        </script>
    <?php
        header("Location: manage.php");
    } else {

    ?>
        <script>
            alert("Data not updated")
        </script>
<?php
        header("Location: update.php");
    }
}
?>