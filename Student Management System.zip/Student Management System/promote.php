<?php
include './dbconnect.php';

// Get the student ID from the URL
$id = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promote Student</title>
    <link rel="stylesheet" href="styles.css">
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
}

.container {
    width: 50%;
    margin: 0 auto;
    background-color: #ffffff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #4CAF50;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin: 10px 0 5px;
    font-weight: bold;
}

label span {
    color: red;
}

select {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 100%;
    box-sizing: border-box;
}

button {
    padding: 15px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #45a049;
}

</style>
</head>
<body>
    <div class="container">
        <h1>PROMOTE STUDENT</h1>
        <form action="promote.php?id=<?php echo $id; ?>" method="post">
            <label for="promoted_class">Class Promoted to<span>*</span></label>
            <select id="class" name="class" required>
                <option value="">Select Class</option>
                <!-- Add options here -->
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>

            <button type="submit" name="submit">PROMOTE</button>
        </form>
    </div>
</body>
</html>

<?php
if (isset($_POST['submit'])) {
    $id = $_GET['id'];
    $class = $_POST['class'];

    $qry = "UPDATE `student` SET `class`='$class' WHERE `id`='$id'";
    $run = mysqli_query($link, $qry);
    if ($run) {
?>
        <script>
            alert("Data updated successfully");
        </script>
        <?php
        header("Location: manage.php");
        exit();
    } else {
        ?>
        <script>
            alert("Data not updated");
        </script>
        <?php
        header("Location: promote.php?id=<?php echo $id; ?>");
        exit();
    }
}
?>
