<?php
$link = mysqli_connect("localhost","root","root","kspl");

if($link){
    echo "Connected successfully";
}else{
    echo "Not connected successfully";
}
?>