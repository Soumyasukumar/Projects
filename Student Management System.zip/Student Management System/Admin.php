<?php
include 'dbconnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
}

.container {
    width: 300px;
    margin: 100px auto;
    background-color: #ffc107;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border: 2px solid #000;
}

h1 {
    text-align: center;
    color: #000;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin: 10px 0 5px;
    font-weight: bold;
    color: #000;
}

input[type="text"],
input[type="password"] {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #000;
    border-radius: 4px;
    width: 100%;
    box-sizing: border-box;
    background-color: #fff3cd;
}

button {
    padding: 10px;
    background-color: #d3d3d3;
    color: #000;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #bbb;
}

    </style>
</head>
<body>
    <div class="container">
        <h1>ADMIN LOGIN</h1>
        <form>
            <label for="name">Username :</label>
            <input type="text" id="name" name="name" placeholder="Enter Your Name" required>

            <label for="password">Password :</label>
            <input type="password" id="password" name="password" placeholder="Enter your Password" required>

            <button type="submit" href="dashboard1.php">Login</button>
        </form>
    </div>
</body>
</html>

<?php

if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $password = $_POST['password'];

    $qry = "INSERT INTO `kgi`(`name`, `password`) VALUES ('$name','$password')";
    $run = mysqli_query($link,$qry);
}

?>