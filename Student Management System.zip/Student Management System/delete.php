<?php
include 'dbconnect.php';

$id = $_GET['id'];

$qry = "DELETE FROM `student` WHERE `id`='$id'";

$run = mysqli_query ($link,$qry);

header("Location: dashboard1.php");

?>