document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('login').addEventListener('submit', function(e) {
        e.preventDefault();

        // Get the selected user role
        var userRole = document.querySelector('input[name="user_type"]:checked');

        // Check if a role is selected
        if (userRole) {
            // Redirect to the corresponding dashboard based on the user role
            if (userRole.value === 'User') {
                window.location.href = 'user-dashboard.html';
            } else if (userRole.value === 'Advocate') {
                window.location.href = 'advocate-dashboard.html';
            } else if (userRole.value === 'Employee') {
                window.location.href = 'employee-dashboard.html';
            }
         } else {
            // If no role is selected, display an error message or take appropriate action
            alert('Please select a user role.');
        }
        
    });
});

