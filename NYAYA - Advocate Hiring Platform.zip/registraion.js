// did't required.

// document.addEventListener('DOMContentLoaded', (event) => {
//     document.getElementById('register').addEventListener('submit', function(e) {
//         e.preventDefault();

//         // Get the selected user type
//         var userType = document.querySelector('input[name="user_type"]:checked');

//         // Check if a user type is selected
//         if (userType) {
//             // Redirect to the corresponding dashboard based on the user type
//             if (userType.value === 'User') {
//                 window.location.href = 'user-dashbord.html';
//             } else if (userType.value === 'Advocate') {
//                 window.location.href = 'advocate-dashboard.html';
//             } else {
//                 // Handle other cases if needed
//                 alert('Invalid user type.');
//             }
//         } else {
//             // If no user type is selected, display an error message or take appropriate action
//             alert('Please select a user type.');
//         }
//     });
// });
