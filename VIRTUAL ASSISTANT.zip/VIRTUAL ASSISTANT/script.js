let btn = document.querySelector("#btn")
let content = document.querySelector("#content")
let voice = document.querySelector("#voice")

function speak(text) {
    let text_speak = new SpeechSynthesisUtterance(text)
    text_speak.rate = 1
    text_speak.pitch = -9
    text_speak.volume = 3
    text_speak.lang = "en-US"
    window.speechSynthesis.speak(text_speak)
}

function wishMe() {
    let day = new Date()
    let hours = day.getHours()
    if (hours >= 0 && hours < 12) {
        speak("Namaste! Good morning Sir")
    }
    else if (hours >= 12 && hours < 16) {
        speak("Namaste! Good afternoon Sir")
    }
    else {
        speak("Namaste! Good evening Sir")
    }
}

window.addEventListener('load', ()=>{
    wishMe()

})
let speechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
let recognition = new speechRecognition()
recognition.onresult = (event) => {
    let currentIndex = event.resultIndex
    let transcript = event.results[currentIndex][0].transcript
    content.innerText = transcript
    console.log(event)
    takeCommand(transcript.toLowerCase())
}

btn.addEventListener("click", () => {
    recognition.start()
    btn.style.display = "none"
    voice.style.display = "block"
})

function takeCommand(message) {
    btn.style.display = "flex"
    voice.style.display = "none"
    if (message.includes("hello") || message.includes("hey")) {
        speak("namaskaara sar,  kana sahajya darkar?");
    }
    else if (message.includes("who are you")) {
        speak("I am virtual assistant Created by Sukumar Sir");
    }
   
    else if (message.includes("Thank you")) {
        console.log("Thank you command detected");
        setTimeout(() => {
            speak("Most welcome");
        }, 500);  // 500ms delay before speaking
    }
    
    


    else if (message.includes("open youtube")) {
        speak("opening youtube...")
        window.open("https://www.youtube.com/")
    }
    else if (message.includes("open google")) {
        speak("opening google...")
        window.open("https://www.google.com/")
    }
    else if (message.includes("open facebook")) {
        speak("opening facebook...")
        window.open("https://www.facebook.com/")
    }
    else if (message.includes("open instagram")) {
        speak("opening instagram...")
        window.open("https://www.instagram.com/")
    }
    
    else if (message.includes("open calculator")) {
        speak("opening calculator...")
        window.open("calculator://")
    }

    else if (message.includes("open whatsapp")) {
        speak("opening calculator...")
        window.open("whatsapp://")
    }

    
     
    
    else if (message.includes("time")) {
        let time=new Date().toLocaleString(undefined,{hour:"numeric",minute:"numeric"})
        speak("Current time is " + time)
    }

    else if (message.includes("date")) {
        let date=new Date().toLocaleString(undefined,{day:"numeric",month:"short"})
        speak("Current time is " + date)
    }

    

    else {
        // List of phrases to remove
        const phrasesToRemove = [
            "siona", "Tell me about", "Who is", "What are the", 
            "What is", "Why is", "Who", "What", "Why", "How does", "Where is"
        ];
    
        // Create a new message by replacing the listed phrases
        let finalText = message;
        phrasesToRemove.forEach(phrase => {
            finalText = finalText.replace(new RegExp(`^${phrase}`, 'i'), '');  // Remove phrase at the beginning of the string
        });
    
        // Remove any leading or trailing whitespace and question mark
        finalText = finalText.replace(/[?]$/, '').trim();
    
        // Fallback if no replacement happens
        finalText = finalText || message;
    
        // Speak the modified text
        speak(`This is what I found on the internet regarding: ${finalText}`);
    
        // Open a Google search with the cleaned-up query
        window.open(`https://www.google.com/search?q=${encodeURIComponent(finalText)}`);
    }
    
    

}


